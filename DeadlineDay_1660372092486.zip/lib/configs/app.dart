import 'package:logger/logger.dart' as log;

final logger = log.Logger();
