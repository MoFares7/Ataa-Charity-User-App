// ignore: constant_identifier_names
enum NavbarItem { home, donation_cam, speed_donation, volunteer, profile }
