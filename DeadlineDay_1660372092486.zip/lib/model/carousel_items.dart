import 'package:easy_localization/easy_localization.dart';

final imageUrl = [
  "assets/images/green-card.png",
];
var subTitle = [tr('Volunteer now and do good'), tr('subtitle_gift')];
var title = [tr('volunteer'), tr('gift')];
